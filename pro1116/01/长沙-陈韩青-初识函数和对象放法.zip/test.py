def getName(srcStr):
    return srcStr.split('the name is ')[1].split(',')[0]
str='A gril come in ,the name is Jack, level 996'
print(getName(str))